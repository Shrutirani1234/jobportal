import React from 'react'
import Navbar from './shared/Navbar'

const home = () => {
  return (
    <div>
      
    </div>
  )
}

export default home
